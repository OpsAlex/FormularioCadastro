﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FormularioCadastro.Entities;

namespace FormularioCadastro
{
    public partial class Fomulario : Form
    {
        List<Pessoas> cadList;
        public Fomulario()
        {
            InitializeComponent();
            cadList = new List<Pessoas>();
            // -- Adicionando dados no combobox
            comboCivil.Items.Add("Solteiro");
            comboCivil.Items.Add("Casado");
            comboCivil.Items.Add("Viuvo");
            comboCivil.Items.Add("Separado");
            comboCivil.SelectedIndex = 0;
        }

        private void btnCad_Click(object sender, EventArgs e)
        {
            int id = -1;
            // validando se ja há cadastro
            foreach (Pessoas people in cadList)
            {
                if (people.Nome == txtNome.Text)
                {
                    id = cadList.IndexOf(people);
                }
            }

            if (txtNome.Text == "")
            {
                MessageBox.Show("Preencha o campo nome.");
                txtNome.Focus();
                return;
                
            }
            else if (txtTel.Text == "(  )     -")
            {
                MessageBox.Show("Preencha o campo telefone.");
                txtTel.Focus();
                return;
            }

            char sexo;

            if (radioM.Checked)
            {
                sexo = 'M';
            }
            else if(radioF.Checked)
            {
                sexo = 'F';
            }
            else
            {
                sexo = 'O';
            }

            Pessoas p = new Pessoas();

            p.Nome = txtNome.Text;
            p.DataNasc = txtDate.Text;
            p.EstCivil = comboCivil.SelectedItem.ToString();
            p.Telefone = txtTel.Text;
            p.Veiculo = checkVeiculo.Checked;
            p.Hab = checkHabi.Checked;
            p.Sexo = sexo;

            if (id < 0)
            {
                cadList.Add(p);
            }
            else
            {
                cadList[id] = p;
            }

            btnLimpar_Click(btnLimpar, EventArgs.Empty);

            Lista();

        }


        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int ID = list.SelectedIndex;
            cadList.RemoveAt(ID);
            Lista();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = string.Empty;
            txtDate.Text = string.Empty;
            comboCivil.SelectedIndex = 0;
            txtTel.Text = string.Empty;
            checkVeiculo.Checked = false;
            checkHabi.Checked = false;
            radioM.Checked = true;
            radioF.Checked = false;
            radioO.Checked = false;
            txtNome.Focus();
        }

        private void Lista()
        {
            list.Items.Clear();

            foreach (Pessoas p in cadList)
            {
                list.Items.Add(p.Nome);
            }

        }

        private void list_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int index = list.SelectedIndex;
            Pessoas p = cadList[index];


            txtNome.Text = p.Nome;
            txtDate.Text = p.DataNasc;
            comboCivil.SelectedItem = p.EstCivil;
            txtTel.Text = p.Telefone;
            checkVeiculo.Checked = p.Veiculo;
            checkHabi.Checked = p.Hab;

            switch (p.Sexo)
            {
                case 'M':
                    radioM.Checked = true;
                    break;
                case 'F':
                    radioF.Checked = true;
                    break;
                default:
                    radioO.Checked = true;
                    break;
            }
        }
    }
}
