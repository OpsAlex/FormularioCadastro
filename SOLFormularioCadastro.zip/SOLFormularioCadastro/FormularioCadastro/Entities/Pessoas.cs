﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormularioCadastro.Entities
{
    class Pessoas
    {
        public string Nome { get; set; }
        public string DataNasc { get; set; }
        public string EstCivil { get; set; }
        public string Telefone { get; set; }
        public bool Veiculo { get; set; }
        public bool Hab { get; set; }
        public char Sexo { get; set; }
    }
}
